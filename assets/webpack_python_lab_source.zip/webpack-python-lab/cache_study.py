"""Measure paired cold/warm webpack cache runs in a temporary local folder."""
import argparse
import json
from pathlib import Path
import statistics
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parent
CONFIG = """const base = require('../webpack.config.cjs');
const path = require('node:path');
module.exports = (env, argv) => {
  const config = base(env, argv);
  config.output.path = path.join(__dirname, 'dist');
  config.cache = {
    type: 'filesystem',
    cacheDirectory: path.join(__dirname, env.cache),
    buildDependencies: {config: [__filename, require.resolve('../webpack.config.cjs')]},
  };
  return config;
};
"""


def study(count):
    samples = {"cold": [], "warm": []}
    cli = ROOT / "node_modules/webpack-cli/bin/cli.js"
    with tempfile.TemporaryDirectory(prefix="cache-study-", dir=ROOT) as scratch:
        config = Path(scratch) / "webpack.cache.cjs"
        config.write_text(CONFIG, encoding="utf-8")
        for pair in range(count):
            for group in ("cold", "warm"):
                start = time.perf_counter()
                result = subprocess.run(
                    ["node", str(cli), "--config", str(config), "--mode", "production",
                     "--env", f"cache=pair-{pair}", "--json"],
                    cwd=ROOT, check=True, capture_output=True,
                )
                elapsed = round((time.perf_counter() - start) * 1000)
                stats = json.loads(result.stdout)
                samples[group].append({"wall_ms": elapsed, "compilation_ms": stats["time"]})
        return {
            "pairs": count,
            "median_ms": {g: {k: statistics.median(s[k] for s in items)
                              for k in ("wall_ms", "compilation_ms")}
                          for g, items in samples.items()},
            "samples": samples,
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", type=int, default=10)
    args = parser.parse_args()
    if args.pairs < 1:
        parser.error("--pairs 必須大於零")
    print(json.dumps(study(args.pairs), indent=2))
