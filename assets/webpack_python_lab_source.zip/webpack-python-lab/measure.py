"""比對 webpack 產出的入口與按需資產；gzip 結果不是實際 HTTP 傳輸量。"""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
CLI = ROOT / "node_modules/webpack-cli/bin/cli.js"


def build(folder, eager=False):
    cmd = ["node", str(CLI), "--mode", "production", "--output-path", str(folder),
           "--json", str(folder.parent / f"{folder.name}.json")]
    if eager:
        cmd.extend(("--env", "eager=1"))
    subprocess.run(cmd, cwd=ROOT, check=True, capture_output=True)
    stats = json.loads((folder.parent / f"{folder.name}.json").read_text(encoding="utf-8"))
    initial = set()
    for entry in stats["entrypoints"].values():
        initial.update(asset["name"] for asset in entry["assets"] if asset["name"].endswith(".js"))
    scripts = {name: (folder / name).read_bytes() for name in sorted(initial)}
    non_initial = {f.relative_to(folder).as_posix(): f.read_bytes()
                   for f in sorted((folder / "assets").glob("*.js"))
                   if f.relative_to(folder).as_posix() not in initial}
    if not scripts:
        raise RuntimeError("沒有可供量測的入口 JavaScript")
    expected = 0 if eager else 1
    if len(non_initial) != expected:
        raise RuntimeError(f"按需 JS 預期 {expected} 檔，實際 {len(non_initial)} 檔")
    index_html = (folder / "index.html").read_text(encoding="utf-8")
    missing = [name for name in scripts if name not in index_html]
    if missing:
        raise RuntimeError(f"產出的 HTML 未引用入口資產：{', '.join(missing)}")
    def sizes(files):
        return {"files": list(files), "raw_bytes": sum(map(len, files.values())),
                "gzip_bytes": sum(len(gzip.compress(v, compresslevel=9, mtime=0))
                                  for v in files.values())}
    return {"initial_js": sizes(scripts), "later_js": sizes(non_initial)}


def tree(folder):
    return {f.relative_to(folder).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in sorted(folder.rglob("*")) if f.is_file()}


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as base:
        root = Path(base)
        lazy = build(root / "lazy")
        eager = build(root / "eager", eager=True)
        build(root / "repeat")
        same_bytes = tree(root / "lazy") == tree(root / "repeat")
        if not same_bytes:
            raise RuntimeError("同一輸入重建的檔名或 SHA-256 不一致")
        results = {"eager": eager, "lazy": lazy, "same_input_same_bytes": same_bytes}
        print(json.dumps(results, indent=2, ensure_ascii=False))
