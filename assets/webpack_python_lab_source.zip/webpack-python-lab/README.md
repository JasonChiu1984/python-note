# webpack × Python：冷卻水回路面板

環境：測試以 Node.js 24.22.3、npm 11.19.1、Python 3 標準函式庫。webpack 只在建置端使用；啟動範例 Python 伺服器後，不需要 Node.js 程序。內建點位與趨勢皆為合成資料，不控制設備。

1. 在解壓目錄執行 `npm ci --ignore-scripts`（從登錄服務安裝 lockfile 固定的開發依賴，需要網路）。
2. `npm run build` 產出 `dist/`。
3. `python3 serve.py` 後開啟 `http://127.0.0.1:8787/field/`。按「讀取合成點位」會請求 `/api/reading`；按「開啟趨勢摘要」才請求趨勢 chunk。
4. `npm run stats` 留存 stats.json；`npm run verify` 比較 eager/lazy 與同輸入重建。輸出只涵蓋 JavaScript，不含 CSS、SVG、HTTP 標頭及網路延遲。若比較其他工具鏈，請使用相同原始碼和壓縮規則。

Windows 若只有 `py`，請用 `py serve.py` 和 `py measure.py`；`npm run verify` 內寫的是 `python3`。量測腳本直接呼叫 Node，且即使開啟 Python 最佳化，驗證不符仍會退出，不輸出成功 JSON。

開發：先啟動 `npm run watch`，再開 Python 伺服器，修改後自行重整。此模式不提供 HMR。開發 map 可留在本地檢查，範例 HTTP 不提供 .map。Python 伺服器限 loopback，是課堂示範，不是正式服務。

故障練習：載入面板後，以開發者工具只阻擋 trend 資產，再按摘要；點位讀取應仍可用。正式部署不要清掉仍被舊頁面引用的資產；原子切換 HTML／release 並保留可回退版本。


## 本機發布回退演練

先安裝現有 lockfile 對應的依賴，再執行 `python3 release_rehearsal.py`。
演練在新的 `rehearsal/` 目錄建置 A、B，寫出 `manifest.json`；
不要在正式資產目錄執行。另開終端執行
`python3 rehearsal/local/serve.py --port 8788`，在瀏覽器開啟
http://127.0.0.1:8788/field/。驗證舊分頁尚未載入趨勢後切換：
`python3 release_rehearsal.py --activate B`。重開分頁驗 B、原分頁驗 A。
`--activate A` 可切回 A，不會刪除 B 的雜湊資產。
Windows 只有 `py` 的環境，把上述 `python3` 換成 `py`。

## Cold/warm filesystem cache

Run `python3 cache_study.py --pairs 10` (Windows: `py cache_study.py --pairs 10`).
The included `cache_samples.json` stores the original 10 pairs. Local timings are not universal.
