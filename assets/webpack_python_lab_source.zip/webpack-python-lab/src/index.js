import {mount} from './ui.js';

mount(() => import(/* webpackChunkName: "trend" */ './trend.js'));
