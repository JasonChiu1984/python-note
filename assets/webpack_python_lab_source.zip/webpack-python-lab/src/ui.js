import './style.css';
import icon from './droplet.svg';

export function mount(loadReport) {
  document.querySelector('#icon').src = icon;
  const read = document.querySelector('#read');
  const report = document.querySelector('#report');
  const result = document.querySelector('#result');
  const detail = document.querySelector('#detail');
  let lastValue;
  read.addEventListener('click', async () => {
    read.disabled = true;
    try {
      const response = await fetch('/api/reading', {
        headers: {Accept: 'application/json'},
        signal: AbortSignal.timeout(3500),
      });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      if (data.quality !== 'good' || !Number.isFinite(data.temperature_c)) {
        throw new Error('回傳資料品質或溫度格式無效');
      }
      lastValue = data.temperature_c;
      result.textContent = '合成點位：' + lastValue.toFixed(1) + ' °C';
    } catch (error) {
      result.textContent = '讀取失敗，保留最後一筆有效值：' +
        (lastValue === undefined ? '無' : lastValue.toFixed(1) + ' °C') +
        '（' + error.message + '）';
    } finally {
      read.disabled = false;
    }
  });
  report.addEventListener('click', async () => {
    report.disabled = true;
    detail.textContent = '載入摘要中';
    try {
      const {summarize} = await loadReport();
      detail.textContent = summarize([6.8, 7.1, 7.4]);
    } catch {
      detail.textContent = '摘要載入失敗，請更新頁面後再試。點位讀取不受影響。';
    } finally {
      report.disabled = false;
    }
  });
}
