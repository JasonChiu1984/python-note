export function summarize(values) {
  if (!values.length || values.some(value => !Number.isFinite(value))) {
    throw new TypeError('摘要需要有效的有限數值');
  }
  const sorted = [...values].sort((a, b) => a - b);
  const midpoint = Math.floor(sorted.length / 2);
  const median = sorted.length % 2
    ? sorted[midpoint]
    : (sorted[midpoint - 1] + sorted[midpoint]) / 2;
  return '合成趨勢：最低 ' + sorted[0].toFixed(1) + ' °C，' +
    '中位 ' + median.toFixed(1) + ' °C，' +
    '最高 ' + sorted.at(-1).toFixed(1) + ' °C';
}
