import {mount} from './ui.js';
import {summarize} from './trend.js';

mount(async () => ({summarize}));
