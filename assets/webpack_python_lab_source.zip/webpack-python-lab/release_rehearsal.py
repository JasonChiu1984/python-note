"""Run from the extracted lab with Node dependencies installed. Only writes ./rehearsal."""
from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def run():
    rehearsal = ROOT / "rehearsal"
    rehearsal.mkdir(exist_ok=False)
    with tempfile.TemporaryDirectory(prefix="build-", dir=rehearsal) as scratch:
        repo = Path(scratch)
        shutil.copytree(ROOT / "src", repo / "src")
        shutil.copy2(ROOT / "webpack.config.cjs", repo)
        for release in ("A", "B"):
            if release == "B":
                trend = repo / "src/trend.js"
                original = trend.read_text(encoding="utf-8")
                if original.count("合成趨勢：") != 1:
                    raise RuntimeError("範例與演練版本不符")
                trend.write_text(original.replace("合成趨勢：", "新版趨勢："), encoding="utf-8")
            cli = ROOT / "node_modules/webpack-cli/bin/cli.js"
            subprocess.run(["node", str(cli), "--mode", "production"], cwd=repo,
                           check=True, capture_output=True)
            shutil.copytree(repo / "dist", rehearsal / release)

    def manifest(release):
        root = rehearsal / release
        return {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest()
                for p in sorted(root.rglob("*")) if p.is_file()}

    a, b = (manifest(r) for r in ("A", "B"))
    evidence = {"unchanged": sorted(n for n in a.keys() & b.keys() if a[n] == b[n]),
                "changed_in_place": sorted(n for n in a.keys() & b.keys() if a[n] != b[n]),
                "only_A": sorted(a.keys() - b.keys()), "only_B": sorted(b.keys() - a.keys())}
    (rehearsal / "manifest.json").write_text(json.dumps(evidence, indent=2) + "\n")
    # Reuse the lab server in a separate directory, not a production store.
    live = rehearsal / "local"
    live.mkdir()
    shutil.copy2(ROOT / "serve.py", live)
    shutil.copytree(rehearsal / "A", live / "dist")
    print(json.dumps(evidence, indent=2))


def activate(rehearsal, release):
    if release not in ("A", "B"):
        raise ValueError("只接受本機演練版本 A 或 B")
    source = rehearsal / release
    dist = rehearsal / "local/dist"
    for path in (source / "assets").glob("*"):
        target = dist / "assets" / path.name
        if target.exists():
            if target.read_bytes() != path.read_bytes():
                raise RuntimeError(f"拒絕原地覆寫不可變資產：{path.name}")
            continue
        temp = target.with_suffix(".pending")
        shutil.copy2(path, temp)
        os.replace(temp, target)
    temp = dist / "index.pending"
    shutil.copy2(source / "index.html", temp)
    os.replace(temp, dist / "index.html")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--activate", choices=("A", "B"))
    options = parser.parse_args()
    if options.activate:
        activate(ROOT / "rehearsal", options.activate)
    else:
        run()
