"""只供課堂驗證的 localhost HTTP 伺服器，不連工廠或第三方設備。"""
import argparse
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

DIST = Path(__file__).resolve().parent / "dist"


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, body, content_type, cache):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == "/api/reading":
            self.reply(200, b'{"temperature_c":7.1,"quality":"good"}',
                       "application/json", "no-store")
            return
        if path == "/field/":
            file = DIST / "index.html"
            cache = "no-cache"
        elif path.startswith("/field/assets/"):
            cached_assets = (DIST / "assets").resolve()
            file = (cached_assets / path.removeprefix("/field/assets/")).resolve()
            if file.parent != cached_assets or file.suffix == ".map":
                self.send_error(404)
                return
            cache = "public, max-age=31536000, immutable"
        else:
            self.send_error(404)
            return
        if not file.is_file():
            self.send_error(404)
            return
        kind = mimetypes.guess_type(file)[0] or "application/octet-stream"
        self.reply(200, file.read_bytes(), kind, cache)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args()
    with ThreadingHTTPServer(("127.0.0.1", args.port), Handler) as server:
        server.serve_forever()
