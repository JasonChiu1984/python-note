const path = require('node:path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = (env = {}, argv = {}) => {
  const production = argv.mode === 'production';
  return {
    mode: production ? 'production' : 'development',
    context: __dirname,
    entry: {dashboard: env.eager === '1' ? './src/eager.js' : './src/index.js'},
    output: {
      path: path.join(__dirname, 'dist'),
      filename: 'assets/[name].[contenthash:16].js',
      chunkFilename: 'assets/[name].[contenthash:16].js',
      assetModuleFilename: 'assets/[name].[contenthash:16][ext]',
      publicPath: '/field/',
      clean: true, // 本機獨立的 dist；不要指向部署中的共享目錄
    },
    module: {
      rules: [
        {test: /[.]css$/i, use: [MiniCssExtractPlugin.loader, 'css-loader']},
        {test: /[.]svg$/i, type: 'asset/resource'},
      ],
    },
    plugins: [
      new HtmlWebpackPlugin({template: './src/index.html'}),
      new MiniCssExtractPlugin({filename: 'assets/[name].[contenthash:16].css'}),
    ],
    optimization: {
      moduleIds: 'deterministic',
      chunkIds: 'deterministic',
      runtimeChunk: 'single',
      splitChunks: {chunks: 'all'},
    },
    devtool: production ? false : 'source-map',
  };
};
